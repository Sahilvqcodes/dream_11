
import 'package:flutter/material.dart';

getFullHeight({required BuildContext context })
{
  return MediaQuery.of(context).size.height;
}
getFullWidth({required BuildContext context })
{
  return MediaQuery.of(context).size.width;
}