import 'package:flutter/material.dart';

import 'contestscreen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final List<Category> _categories = [
    Category('Cricket', Icons.sports_baseball),
    Category('Kabaddi', Icons.sports_kabaddi),
    Category('Basketball', Icons.sports_basketball_outlined),
    Category('Basketball', Icons.sports_basketball),
    Category(
      'Handball',
      Icons.sports_handball,
    ),
  ];

  var list = GestureDetector(


    child: Container(
      height: 250,
      width: 100,
      decoration: BoxDecoration(border: Border.all(color: Colors.black38)),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "ICC Men's T20 World Cup",
                  style: TextStyle(color: Colors.black38),
                ),
                IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.notification_add,
                      color: Colors.black38,
                    ))
              ],


            ),
            const Divider(
              color: Colors.black38,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text(
                  "Sri Lanka",
                  style: TextStyle(color: Colors.black),
                ),
                Text(
                  "United Arab Emirates",
                  style: TextStyle(color: Colors.black),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                // Icon(Icons.arrow_right, size: 80,
                //                      color: Colors.yellow,),
                Container(
                  height: 35,
                  width: 40,
                  decoration: const BoxDecoration(shape: BoxShape.circle),
                  child: Image.asset(
                    "assets/images/sl.png",
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(width: 10),

                const Text(
                  "SL",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 60),

                const Text(
                  "24h 24m",
                  style: TextStyle(
                      color: Colors.red,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(width: 60),

                const Text(
                  "UAE",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  width: 10,
                ),

                Container(
                  height: 30,
                  width: 40,
                  decoration: const BoxDecoration(shape: BoxShape.circle),
                  child: Image.asset(
                    "assets/images/uae.png",
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "8 Crores",
                  style: TextStyle(color: Colors.black38),
                ),
                IconButton(
                    onPressed: () {},
                    icon: const Icon(
                      Icons.mic,
                      color: Colors.black38,
                    ))
              ],
            ),
          ],
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Row(
            children:  [
              IconButton(onPressed: (){
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => ConstestScreen()));


              }, icon:Icon(
                Icons.notification_add,
                color: Colors.white,
              ),),

              SizedBox(
                width: 10,
              ),
              Icon(
                Icons.wallet,
                color: Colors.white,
              ),
              SizedBox(
                width: 10,
              ),
            ],
          )
        ],
        backgroundColor: const Color(0xffC90000),
      ),
      drawer: const Drawer(),


      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Container(
            // color: Colors.green,

            color: const Color(0xffF5F5F5),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 80,
                  child: Expanded(
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: _categories.map((data) {
                        return Container(
                          width: 90,
                          height: 60,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.black38),
                            shape: BoxShape.circle,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Center(
                                child: Icon(
                                  data.icon,
                                  color: Colors.black38,
                                ),
                              ),
                              Text(
                                data.name,
                                style: const TextStyle(
                                    color: Colors.black38, fontSize: 15),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(
                    "Upcoming Matches ",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  height: 500,
                  width: double.infinity,
                  child: ListView.builder(
                      itemCount: 5,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                          child: list,
                        );
                      }),
                ),


              ],
            ),
          ),
        ),

      ),

        bottomNavigationBar:  BottomNavigationBar(
        unselectedLabelStyle: const TextStyle(color: Colors.black, fontSize: 14),
        backgroundColor: Colors.black,


        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home, color: Colors.black38),


            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.wine_bar,
              color: Colors.black38,
            ),
            label: 'My Match',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.flare_outlined,
              color: Colors.black38,
            ),
            label: 'Winners',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.chat,
              color: Colors.black38,
            ),
            label: 'Chat',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.card_giftcard_outlined,
              color: Colors.black38,
            ),
            label: 'Rewards',
          ),
        ],
        currentIndex: index,
        onTap: (int i){setState((){index = i;});},
        fixedColor: Colors.red,
      ),



    );
  }
}

class Category {
  String name;
  IconData icon;

  Category(this.name, this.icon);
}
