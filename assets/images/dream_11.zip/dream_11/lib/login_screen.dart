import 'package:dream_11/information.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController controllerForPhone = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Login",
            style: TextStyle(
                decoration: TextDecoration.none,
                color: Colors.white,
                fontSize: 20)),


        backgroundColor: const Color(0xffC90000),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.only(top: 50, left: 20, right: 20),
          child: Column(
            children: [
              SizedBox(
                width: 350,
                child: TextFormField(
                  controller: controllerForPhone,
                  keyboardType: TextInputType.phone,
                  validator: (value) => validatePhone(value),
                  decoration: const InputDecoration(
                      hintText: "Email or  Mobile Number"),
                ),
              ),
              const SizedBox(height: 50),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => HomeScreen()));
                },
                child: Container(
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    //color:Color(0xffF5F5F5),
                    color: Colors.grey,
                  ),

                  height: 50,
                  width: 350,
                  //color: Colors.white,

                    child: TextButton(child:const Text(
                      "Next",
                      style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.bold,
                          color: Colors.black54,
                          fontSize: 15),),
                      onPressed: (){


                        Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (context) => HomeScreen()));
                      },
                    ),
                  ),
                ),

              const SizedBox(height: 450,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text('Not a Member ?', style: TextStyle(color: Colors.grey, fontSize: 15)),
                  TextButton(onPressed: (){
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) => Information()));

                  }, child:const Text("Register",style: TextStyle(color: Colors.black, fontSize: 15)))
                ],
              )


            ],
          ),
        ),
      ),
    );
  }

  String? validatePhone(String? value) {
    String pattern = r"^[0-9]{10}$";

    RegExp regex = RegExp(pattern);
    if (value == null || value.isEmpty || !regex.hasMatch(value)) {
      return 'Enter a valid Phone Number';
    } else {
      return null;
    }
  }
}
