import 'package:flutter/material.dart';

class ConstestScreen extends StatefulWidget {
  const ConstestScreen({Key? key}) : super(key: key);

  @override
  State<ConstestScreen> createState() => _ConstestScreenState();
}

class _ConstestScreenState extends State<ConstestScreen> {
  var list = Container(
    height: 250,
    width: 100,
    decoration: BoxDecoration(border: Border.all(color: Colors.black38)),
    child: Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: const [
              Text(
                "Prize Pool",
                style: TextStyle(color: Colors.black38),
              ),
              Text(
                "Entry",
                style: TextStyle(color: Colors.black38),
              ),


            ],


          ),
          const SizedBox(height:20),


          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children:  [
              const Text(
                "10 Lakh",
                style: TextStyle(color: Colors.black,fontSize: 20),
              ),
              GestureDetector(
                child: Container(
                  decoration: const BoxDecoration(
                      color: Colors.green,
                    borderRadius: BorderRadius.all(Radius.circular(10))
                  ),
                  height: 30,
                  width: 50,

                  child: const Center(
                    child: Text(
                      "20Rs",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const LinearProgressIndicator(
            backgroundColor: Color(0xffFBB548),
            valueColor: AlwaysStoppedAnimation(Colors.yellow),
            minHeight: 5.0,
          ),
          const SizedBox(height:10),

          Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: const [






            Text(
              "5153 Spots left",
              style: TextStyle(
                  color:Color(0xffFBB548),
                  fontSize: 15,
                  fontWeight: FontWeight.bold),
            ),
            Text(
              "5333 Sposts",
              style: TextStyle(
                  color: Colors.black38,
                  fontSize: 15,
                  ),
            ),
      ],
    ),
          const SizedBox(height: 10),
          Container(
            height: 50,
            width: 350,
            decoration: const BoxDecoration(
                color: Colors.red,
                borderRadius: BorderRadius.all(Radius.circular(10))
            ),
            child: Row(
              children:  [
Icon(Icons.flare_outlined,color: Colors.white,),





                Text(
                  "95,000",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(width: 60),
                Icon(Icons.wine_bar,color:Colors.white),

                Text(
                  "54%",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(width: 60),


                Text(
                  "Guaranteed",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  width: 10,
                ),





        ],
      ),
          ),
      ]
      ),
    ),

  );
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        
        backgroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 50,
              width: MediaQuery.of(context).size.width,
              color: Colors.red,
            ),




            Padding(padding: EdgeInsets.all(15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [

                const Text("Special For You",style:
                TextStyle(color: Colors.black,fontSize: 20)),

                TextButton(onPressed: (){}, child: const Text("View All",
                  style: TextStyle(color: Colors.black,fontSize: 20),
                ))
              ],),
            ),
            Padding(
              padding: const EdgeInsets.all(15.0),
              child: SizedBox(
                height: 500,
                width: double.infinity,
                child: ListView.builder(
                    //itemCount: 5,
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.fromLTRB(0, 10, 0, 10),
                        child: list,
                      );
                    }),
              ),
            ),


          ],
        ),
      ),


    );
  }
}
