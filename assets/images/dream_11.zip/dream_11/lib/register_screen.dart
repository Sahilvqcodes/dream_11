import 'package:flutter/material.dart';

import 'information.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  TextEditingController controllerForPhone = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Register & Play",
            style: TextStyle(
                decoration: TextDecoration.none,
                color: Colors.white,
                fontSize: 20)),


        backgroundColor: Color(0xffC90000),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 50, left: 20, right: 20),
          child: Column(
            children: [
              SizedBox(
                width: 350,
                child: TextFormField(
                  controller: controllerForPhone,
                  keyboardType: TextInputType.phone,
                  validator: (value) => validatePhone(value),
                  decoration: const InputDecoration(hintText: "Enter Mobile Number"),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(right: 150),
                child: Text(
                  "You'll receive an OTP for verification",
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
              SizedBox(height: 50),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => LoginScreen()));
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    //color:Color(0xffF5F5F5),
                    color: Colors.grey,
                  ),

                  height: 50,
                  width: 350,
                  //color: Colors.white,
                  child: const Center(
                    child: Text(
                      "REGISTER",
                      style: TextStyle(
                          decoration: TextDecoration.none,
                          fontWeight: FontWeight.bold,
                          color: Colors.black54,
                          fontSize: 15),
                    ),
                  ),
                ),
              ),
              Text(
                "By Registering, I agree to Dream11's T&Cs",
                style: TextStyle(color: Colors.grey, fontSize: 12),
              ),
              SizedBox(
                height: 400,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    "Have a Referral Code?",
                    style: TextStyle(
                        decoration: TextDecoration.none,
                        fontSize: 15,
                        color: Colors.grey),
                  ),
                  Text(
                    "Already a User ?",
                    style: TextStyle(
                        decoration: TextDecoration.none,
                        fontSize: 15,
                        color: Colors.grey),
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: const [
                  Text(
                    "Enter Code",
                    style: TextStyle(
                        decoration: TextDecoration.none,
                        fontSize: 12,
                        color: Colors.black),
                  ),
                  Text(
                    "Log In",
                    style: TextStyle(
                        decoration: TextDecoration.none,
                        fontSize: 12,
                        color: Colors.black),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String? validatePhone(String? value) {
    String pattern = r"^[0-9]{10}$";

    RegExp regex = RegExp(pattern);
    if (value == null || value.isEmpty || !regex.hasMatch(value)) {
      return 'Enter a valid Phone Number';
    } else {
      return null;
    }
  }
}
